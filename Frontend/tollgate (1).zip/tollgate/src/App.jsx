import React, { useState, useRef, useEffect, useCallback } from "react";
import {
  Shield, ShieldCheck, ShieldOff, Clock, Zap, Wallet, Activity, TrendingUp,
  AlertTriangle, CheckCircle2, XCircle, Search, Plus, ChevronRight, ArrowUpRight,
  Link2, Radio, Settings2, Filter, X, Bot, Landmark, ListChecks, GitBranch, Loader2
} from "lucide-react";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from "recharts";

/* ---------------------------------- helpers ---------------------------------- */

const B32 = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ";
const rnd = (n) => Array.from({ length: n }, () => B32[Math.floor(Math.random() * B32.length)]).join("");
const uid = () => Math.random().toString(36).slice(2, 9);
const genAddr = () => rnd(4) + "..." + rnd(4);
const genTxHash = () => rnd(6) + "..." + rnd(4);
const usd = (n) => `$${n.toFixed(2)}`;
const algo = (n) => `${n.toFixed(2)} ALGO`;
const ALGO_RATE = 0.18;
let ROUND = 48213904;

const CATEGORIES = ["search", "maps", "data", "compute", "storage", "messaging", "email", "media"];

const now = () => {
  const d = new Date();
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
};

/* ---------------------------------- seed data ---------------------------------- */

const seedAgents = () => [
  {
    id: "a1", name: "Scout-07", role: "Web Research Agent",
    dailyLimit: 50, perTxLimit: 10, autoApproveUnder: 5,
    allowedCategories: ["search", "maps", "data"],
    spentToday: 12.4, weekSpent: 61.2, status: "active", wallet: genAddr(), balance: 340.5,
  },
  {
    id: "a2", name: "Forge-Bot", role: "Code Deployment Agent",
    dailyLimit: 200, perTxLimit: 75, autoApproveUnder: 25,
    allowedCategories: ["compute", "storage"],
    spentToday: 145.0, weekSpent: 812.4, status: "active", wallet: genAddr(), balance: 1120.0,
  },
  {
    id: "a3", name: "Concierge-AI", role: "Customer Ops Agent",
    dailyLimit: 30, perTxLimit: 15, autoApproveUnder: 5,
    allowedCategories: ["messaging", "email"],
    spentToday: 28.5, weekSpent: 133.9, status: "flagged", wallet: genAddr(), balance: 58.2,
  },
];

const seedTxns = (agents) => {
  const svc = {
    search: "/v1/search/query", maps: "/v1/maps/route", data: "/v1/data/enrich",
    compute: "/v1/compute/job", storage: "/v1/storage/put", messaging: "/v1/sms/send",
    email: "/v1/email/send", media: "/v1/media/render",
  };
  const list = [];
  for (let i = 0; i < 9; i++) {
    const ag = agents[i % agents.length];
    const cat = ag.allowedCategories[i % ag.allowedCategories.length];
    const amt = +(Math.random() * (ag.perTxLimit * 0.9) + 0.5).toFixed(2);
    const denied = i === 2;
    const hold = i === 5;
    list.push({
      id: uid(),
      time: `${9 + i}:1${i}:0${i % 6}`,
      agentId: ag.id, agentName: ag.name,
      service: svc[cat], category: cat, amount: amt,
      status: denied ? "closed" : hold ? "hold" : "open",
      reason: denied ? "category not allowlisted for agent" : hold ? "exceeds per-transaction limit" : "within policy limits",
      txHash: denied || hold ? null : genTxHash(),
      round: denied || hold ? null : ROUND++,
      approver: denied || hold ? null : "policy-engine",
    });
  }
  return list;
};

const weeklyTotals = [
  { day: "Mon", spend: 118 }, { day: "Tue", spend: 146 }, { day: "Wed", spend: 97 },
  { day: "Thu", spend: 205 }, { day: "Fri", spend: 168 }, { day: "Sat", spend: 54 }, { day: "Sun", spend: 71 },
];

const categoryTotals = [
  { name: "compute", value: 340 }, { name: "storage", value: 120 }, { name: "data", value: 88 },
  { name: "search", value: 62 }, { name: "maps", value: 41 }, { name: "messaging", value: 28 },
  { name: "email", value: 15 }, { name: "media", value: 9 },
];

const PIE_COLORS = ["#4FD1C5", "#E8A33D", "#7C9EF2", "#3FA66B", "#C4503A", "#B48CD9", "#5FB0DE", "#D3963B"];

/* ---------------------------------- shared bits ---------------------------------- */

const GLOBAL_CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500;600&display=swap');

  .tg-root { font-family:'IBM Plex Sans',sans-serif; background:#0D1420; color:#EDF1F5; min-height:100%; }
  .tg-display { font-family:'Space Grotesk',sans-serif; }
  .tg-mono { font-family:'IBM Plex Mono',monospace; font-variant-numeric: tabular-nums; }
  .tg-panel { background:#141D2B; border:1px solid #232F40; border-radius:10px; }
  .tg-panel-raised { background:#1A2434; border:1px solid #2B3648; border-radius:10px; }
  .tg-hairline { border-color:#232F40; }
  .tg-muted { color:#8C99AC; }
  .tg-faint { color:#5D6B80; }
  .tg-accent-chain { color:#4FD1C5; }
  .tg-bg-accent-chain { background:#4FD1C5; }
  .tg-accent-signal { color:#E8A33D; }
  .tg-bg-accent-signal { background:#E8A33D; }
  .tg-stamp-open { color:#3FA66B; border-color:#2F5B41; background:rgba(63,166,107,0.1); }
  .tg-stamp-closed { color:#E28873; border-color:#6B392E; background:rgba(196,80,58,0.12); }
  .tg-stamp-hold { color:#E8B25E; border-color:#6B4F22; background:rgba(216,150,59,0.12); }
  .tg-tab-active { background:#1A2434; color:#EDF1F5; border-color:#2B3648; }
  .tg-tab { color:#8C99AC; border-color:transparent; }
  .tg-tab:hover { color:#EDF1F5; }
  .tg-input { background:#0F1620; border:1px solid #2B3648; color:#EDF1F5; border-radius:6px; }
  .tg-input:focus { outline:none; border-color:#4FD1C5; }
  .tg-btn-primary { background:#4FD1C5; color:#0D1420; font-weight:600; }
  .tg-btn-primary:hover { background:#6BDBD1; }
  .tg-btn-primary:disabled { background:#2B3648; color:#5D6B80; cursor:not-allowed; }
  .tg-btn-ghost { background:transparent; border:1px solid #2B3648; color:#EDF1F5; }
  .tg-btn-ghost:hover { border-color:#4FD1C5; color:#4FD1C5; }
  .tg-chip { border:1px solid #2B3648; color:#8C99AC; border-radius:999px; }
  .tg-chip-on { border-color:#4FD1C5; color:#4FD1C5; background:rgba(79,209,197,0.08); }
  .tg-scrollbar::-webkit-scrollbar { width:6px; height:6px; }
  .tg-scrollbar::-webkit-scrollbar-thumb { background:#2B3648; border-radius:3px; }
  @keyframes tickerIn { from { opacity:0; transform:translateY(-6px); } to { opacity:1; transform:translateY(0); } }
  .tg-ticker-item { animation: tickerIn 0.35s ease-out; }
  @keyframes pulseDot { 0%,100% { opacity:1; } 50% { opacity:0.35; } }
  .tg-pulse { animation: pulseDot 1.6s ease-in-out infinite; }
  .tg-focus:focus-visible { outline:2px solid #4FD1C5; outline-offset:2px; }
`;

function StampBadge({ status, size = "sm" }) {
  const map = {
    open: { label: "GATE OPEN", cls: "tg-stamp-open", Icon: CheckCircle2 },
    closed: { label: "GATE CLOSED", cls: "tg-stamp-closed", Icon: XCircle },
    hold: { label: "GATE HOLD", cls: "tg-stamp-hold", Icon: Clock },
  };
  const m = map[status] || map.hold;
  const pad = size === "lg" ? "px-3 py-1.5 text-sm" : "px-2 py-0.5 text-xs";
  return (
    <span className={`tg-mono inline-flex items-center gap-1.5 border rounded ${pad} ${m.cls} tracking-wide font-medium`}>
      <m.Icon size={size === "lg" ? 14 : 12} strokeWidth={2.5} />
      {m.label}
    </span>
  );
}

function StatCard({ icon: Icon, label, value, sub, accent }) {
  return (
    <div className="tg-panel p-4 flex flex-col gap-2 min-w-0">
      <div className="flex items-center justify-between">
        <span className="tg-muted text-xs uppercase tracking-wider">{label}</span>
        <Icon size={16} className={accent ? "tg-accent-chain" : "tg-faint"} />
      </div>
      <div className="tg-mono tg-display text-2xl font-semibold truncate">{value}</div>
      {sub && <div className="tg-faint text-xs">{sub}</div>}
    </div>
  );
}

/* ---------------------------------- ticker tape (signature element) ---------------------------------- */

function TickerTape({ events }) {
  const boxRef = useRef(null);
  useEffect(() => {
    if (boxRef.current) boxRef.current.scrollTop = 0;
  }, [events.length]);

  return (
    <div className="tg-panel-raised px-4 py-3">
      <div className="flex items-center gap-2 mb-2">
        <Radio size={13} className="tg-accent-signal tg-pulse" />
        <span className="tg-mono text-xs tg-accent-signal tracking-widest uppercase">Live Gate Feed</span>
        <span className="tg-faint text-xs">— every x402 request &amp; settlement, as it happens</span>
      </div>
      <div ref={boxRef} className="tg-mono text-xs space-y-1 max-h-32 overflow-y-auto tg-scrollbar pr-1">
        {events.length === 0 && <div className="tg-faint">Waiting for agent activity…</div>}
        {events.map((e) => (
          <div key={e.id} className="tg-ticker-item flex items-center gap-2 whitespace-nowrap">
            <span className="tg-faint">{e.time}</span>
            <span className="tg-muted">{e.agentName}</span>
            <span className="tg-faint">→</span>
            <span>{e.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------------------------- Overview ---------------------------------- */

function Overview({ agents, txns, treasury, ticker, setTab }) {
  const totalSpentToday = agents.reduce((s, a) => s + a.spentToday, 0);
  const totalDailyCap = agents.reduce((s, a) => s + a.dailyLimit, 0);
  const holds = txns.filter((t) => t.status === "hold").length;
  const closedToday = txns.filter((t) => t.status === "closed").length;

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={Wallet} label="Treasury Balance" value={algo(treasury)} sub={usd(treasury * ALGO_RATE) + " equiv."} accent />
        <StatCard icon={TrendingUp} label="Spent Today" value={usd(totalSpentToday)} sub={`of ${usd(totalDailyCap)} combined cap`} />
        <StatCard icon={Clock} label="Pending Approvals" value={holds} sub={holds ? "awaiting a human decision" : "queue is clear"} />
        <StatCard icon={ShieldOff} label="Blocked by Policy" value={closedToday} sub="requests stopped today" />
      </div>

      <TickerTape events={ticker} />

      <div className="tg-panel p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="tg-display font-semibold text-sm">Agent roster</h3>
          <button onClick={() => setTab("policies")} className="text-xs tg-accent-chain flex items-center gap-1 hover:underline">
            Manage policies <ChevronRight size={14} />
          </button>
        </div>
        <div className="space-y-2">
          {agents.map((a) => {
            const pct = Math.min(100, (a.spentToday / a.dailyLimit) * 100);
            return (
              <div key={a.id} className="flex items-center gap-3 py-2 border-b tg-hairline last:border-0">
                <div className="w-8 h-8 rounded-full tg-panel-raised flex items-center justify-center shrink-0">
                  <Bot size={15} className="tg-accent-chain" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium truncate">{a.name}</span>
                    <span className="tg-faint text-xs truncate">{a.role}</span>
                    {a.status === "flagged" && (
                      <span className="tg-mono text-[10px] tg-accent-signal border tg-stamp-hold rounded px-1.5 py-0.5">FLAGGED</span>
                    )}
                  </div>
                  <div className="h-1.5 bg-[#0F1620] rounded-full mt-1.5 overflow-hidden">
                    <div
                      className="h-full rounded-full tg-bg-accent-chain"
                      style={{ width: `${pct}%`, background: pct > 90 ? "#C4503A" : undefined }}
                    />
                  </div>
                </div>
                <div className="tg-mono text-xs text-right shrink-0">
                  <div>{usd(a.spentToday)} / {usd(a.dailyLimit)}</div>
                  <div className="tg-faint">cap / day</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------- Policies ---------------------------------- */

function Policies({ agents, updateAgent, addAgent }) {
  const [editing, setEditing] = useState(null);
  const [draft, setDraft] = useState({});
  const [adding, setAdding] = useState(false);
  const [newAgent, setNewAgent] = useState({
    name: "", role: "", dailyLimit: 50, perTxLimit: 10, autoApproveUnder: 5, allowedCategories: [],
  });

  const startEdit = (a) => { setEditing(a.id); setDraft({ ...a }); };
  const save = () => { updateAgent(editing, draft); setEditing(null); };
  const toggleCat = (cat, target, setter) => {
    const has = target.allowedCategories.includes(cat);
    setter({ ...target, allowedCategories: has ? target.allowedCategories.filter((c) => c !== cat) : [...target.allowedCategories, cat] });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="tg-display font-semibold">Policy rules</h3>
          <p className="tg-muted text-sm">Every gate decision is evaluated against these limits — nothing spends without passing through them.</p>
        </div>
        <button onClick={() => setAdding((v) => !v)} className="tg-btn-ghost rounded-md px-3 py-2 text-sm flex items-center gap-1.5">
          <Plus size={14} /> New agent
        </button>
      </div>

      {adding && (
        <div className="tg-panel p-4 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <input className="tg-input px-3 py-2 text-sm" placeholder="Agent name" value={newAgent.name}
              onChange={(e) => setNewAgent({ ...newAgent, name: e.target.value })} />
            <input className="tg-input px-3 py-2 text-sm" placeholder="Role" value={newAgent.role}
              onChange={(e) => setNewAgent({ ...newAgent, role: e.target.value })} />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <label className="text-xs tg-muted flex flex-col gap-1">Daily cap ($)
              <input type="number" className="tg-input px-3 py-2 text-sm" value={newAgent.dailyLimit}
                onChange={(e) => setNewAgent({ ...newAgent, dailyLimit: +e.target.value })} />
            </label>
            <label className="text-xs tg-muted flex flex-col gap-1">Per-transaction cap ($)
              <input type="number" className="tg-input px-3 py-2 text-sm" value={newAgent.perTxLimit}
                onChange={(e) => setNewAgent({ ...newAgent, perTxLimit: +e.target.value })} />
            </label>
            <label className="text-xs tg-muted flex flex-col gap-1">Auto-approve under ($)
              <input type="number" className="tg-input px-3 py-2 text-sm" value={newAgent.autoApproveUnder}
                onChange={(e) => setNewAgent({ ...newAgent, autoApproveUnder: +e.target.value })} />
            </label>
          </div>
          <div>
            <div className="text-xs tg-muted mb-1.5">Allowed categories</div>
            <div className="flex flex-wrap gap-1.5">
              {CATEGORIES.map((c) => (
                <button key={c} onClick={() => toggleCat(c, newAgent, setNewAgent)}
                  className={`tg-mono text-xs px-2.5 py-1 rounded-full border ${newAgent.allowedCategories.includes(c) ? "tg-chip-on" : "tg-chip"}`}>
                  {c}
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-2 justify-end">
            <button onClick={() => setAdding(false)} className="tg-btn-ghost rounded-md px-3 py-1.5 text-sm">Cancel</button>
            <button
              disabled={!newAgent.name}
              onClick={() => { addAgent(newAgent); setAdding(false); setNewAgent({ name: "", role: "", dailyLimit: 50, perTxLimit: 10, autoApproveUnder: 5, allowedCategories: [] }); }}
              className="tg-btn-primary rounded-md px-3 py-1.5 text-sm">
              Create agent
            </button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {agents.map((a) => (
          <div key={a.id} className="tg-panel p-4">
            {editing === a.id ? (
              <div className="space-y-3">
                <div className="grid grid-cols-3 gap-3">
                  <label className="text-xs tg-muted flex flex-col gap-1">Daily cap ($)
                    <input type="number" className="tg-input px-3 py-2 text-sm" value={draft.dailyLimit}
                      onChange={(e) => setDraft({ ...draft, dailyLimit: +e.target.value })} />
                  </label>
                  <label className="text-xs tg-muted flex flex-col gap-1">Per-transaction cap ($)
                    <input type="number" className="tg-input px-3 py-2 text-sm" value={draft.perTxLimit}
                      onChange={(e) => setDraft({ ...draft, perTxLimit: +e.target.value })} />
                  </label>
                  <label className="text-xs tg-muted flex flex-col gap-1">Auto-approve under ($)
                    <input type="number" className="tg-input px-3 py-2 text-sm" value={draft.autoApproveUnder}
                      onChange={(e) => setDraft({ ...draft, autoApproveUnder: +e.target.value })} />
                  </label>
                </div>
                <div>
                  <div className="text-xs tg-muted mb-1.5">Allowed categories</div>
                  <div className="flex flex-wrap gap-1.5">
                    {CATEGORIES.map((c) => (
                      <button key={c} onClick={() => toggleCat(c, draft, setDraft)}
                        className={`tg-mono text-xs px-2.5 py-1 rounded-full border ${draft.allowedCategories.includes(c) ? "tg-chip-on" : "tg-chip"}`}>
                        {c}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex gap-2 justify-end">
                  <button onClick={() => setEditing(null)} className="tg-btn-ghost rounded-md px-3 py-1.5 text-sm">Cancel</button>
                  <button onClick={save} className="tg-btn-primary rounded-md px-3 py-1.5 text-sm">Save policy</button>
                </div>
              </div>
            ) : (
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{a.name}</span>
                    <span className="tg-faint text-xs">{a.role}</span>
                  </div>
                  <div className="tg-mono text-xs tg-muted mt-1 flex flex-wrap gap-x-4 gap-y-1">
                    <span>daily cap <b className="text-[#EDF1F5]">{usd(a.dailyLimit)}</b></span>
                    <span>per-tx cap <b className="text-[#EDF1F5]">{usd(a.perTxLimit)}</b></span>
                    <span>auto-approve &lt; <b className="text-[#EDF1F5]">{usd(a.autoApproveUnder)}</b></span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {a.allowedCategories.map((c) => (
                      <span key={c} className="tg-mono text-[11px] tg-chip px-2 py-0.5 rounded-full">{c}</span>
                    ))}
                  </div>
                </div>
                <button onClick={() => startEdit(a)} className="tg-btn-ghost rounded-md px-3 py-1.5 text-xs shrink-0 flex items-center gap-1.5">
                  <Settings2 size={13} /> Edit
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------------------------- x402 Gate simulator ---------------------------------- */

function GateSimulator({ agents, onSettle }) {
  const [agentId, setAgentId] = useState(agents[0]?.id);
  const [service, setService] = useState("/v1/maps/route");
  const [category, setCategory] = useState("maps");
  const [amount, setAmount] = useState(3.5);
  const [steps, setSteps] = useState([]);
  const [running, setRunning] = useState(false);
  const timers = useRef([]);

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const push = (step) => setSteps((s) => [...s, step]);

  const run = () => {
    const agent = agents.find((a) => a.id === agentId);
    if (!agent || running) return;
    setSteps([]);
    setRunning(true);
    timers.current = [];

    push({ label: `${agent.name} calls ${service}`, detail: "HTTP 402 Payment Required returned by upstream service", tone: "signal" });

    timers.current.push(setTimeout(() => {
      push({ label: "Policy engine evaluating request", detail: `checking category, per-tx cap, and remaining daily budget for ${agent.name}`, tone: "muted" });
    }, 500));

    timers.current.push(setTimeout(() => {
      let decision, reason;
      if (!agent.allowedCategories.includes(category)) {
        decision = "closed"; reason = `"${category}" is not an allowlisted category for ${agent.name}`;
      } else if (amount > agent.perTxLimit) {
        decision = "hold"; reason = `${usd(amount)} exceeds the ${usd(agent.perTxLimit)} per-transaction cap — needs a human`;
      } else if (agent.spentToday + amount > agent.dailyLimit) {
        decision = "hold"; reason = `would push daily spend past the ${usd(agent.dailyLimit)} cap — needs a human`;
      } else {
        decision = "open"; reason = "within category, per-transaction, and daily limits";
      }
      push({ label: `Decision: ${decision === "open" ? "authorize" : decision === "hold" ? "escalate" : "deny"}`, detail: reason, tone: decision });

      if (decision === "open") {
        timers.current.push(setTimeout(() => {
          push({ label: "Submitting settlement to Algorand", detail: "signing payment from agent sub-wallet to service provider", tone: "muted" });
        }, 500));
        timers.current.push(setTimeout(() => {
          const txHash = genTxHash();
          const round = ROUND++;
          push({ label: "Settlement confirmed on-chain", detail: `tx ${txHash} · round ${round}`, tone: "open" });
          push({ label: "200 OK returned to agent", detail: "payment receipt attached, original request retried and served", tone: "open" });
          onSettle({ agentId, agentName: agent.name, service, category, amount, status: "open", reason, txHash, round, approver: "policy-engine" });
          setRunning(false);
        }, 1200));
      } else {
        timers.current.push(setTimeout(() => {
          push({ label: decision === "hold" ? "Queued in Approvals" : "Request terminated", detail: decision === "hold" ? "an operator can approve or deny this from the Audit Log" : "no funds moved, agent receives 402 unresolved", tone: decision });
          onSettle({ agentId, agentName: agent.name, service, category, amount, status: decision, reason, txHash: null, round: null, approver: null });
          setRunning(false);
        }, 500));
      }
    }, 1100));
  };

  const toneCls = { signal: "tg-accent-signal", muted: "tg-muted", open: "text-[#3FA66B]", closed: "text-[#E28873]", hold: "text-[#E8B25E]" };

  return (
    <div className="space-y-4">
      <div>
        <h3 className="tg-display font-semibold">x402 payment gate</h3>
        <p className="tg-muted text-sm">Every paid call an agent makes is routed through this gate — the 402 handshake, the policy check, and (if authorized) the Algorand settlement.</p>
      </div>

      <div className="tg-panel p-4 grid md:grid-cols-2 gap-3">
        <label className="text-xs tg-muted flex flex-col gap-1">Agent
          <select className="tg-input px-3 py-2 text-sm" value={agentId} onChange={(e) => setAgentId(e.target.value)}>
            {agents.map((a) => <option key={a.id} value={a.id}>{a.name} — {a.role}</option>)}
          </select>
        </label>
        <label className="text-xs tg-muted flex flex-col gap-1">Category
          <select className="tg-input px-3 py-2 text-sm" value={category} onChange={(e) => setCategory(e.target.value)}>
            {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </label>
        <label className="text-xs tg-muted flex flex-col gap-1">Service endpoint
          <input className="tg-input px-3 py-2 text-sm tg-mono" value={service} onChange={(e) => setService(e.target.value)} />
        </label>
        <label className="text-xs tg-muted flex flex-col gap-1">Amount (USD)
          <input type="number" step="0.5" className="tg-input px-3 py-2 text-sm tg-mono" value={amount} onChange={(e) => setAmount(+e.target.value)} />
        </label>
        <div className="md:col-span-2 flex justify-end">
          <button onClick={run} disabled={running} className="tg-btn-primary rounded-md px-4 py-2 text-sm flex items-center gap-2">
            {running ? <Loader2 size={14} className="animate-spin" /> : <Zap size={14} />}
            {running ? "Processing…" : "Send paid request"}
          </button>
        </div>
      </div>

      <div className="tg-panel-raised p-4 min-h-[220px]">
        <div className="tg-mono text-xs tg-faint uppercase tracking-widest mb-3">Request trace</div>
        {steps.length === 0 && <div className="tg-faint text-sm">Send a request above to watch it move through the gate.</div>}
        <div className="space-y-3">
          {steps.map((s, i) => (
            <div key={i} className="tg-ticker-item flex gap-3">
              <div className={`tg-mono text-xs shrink-0 w-5 pt-0.5 ${toneCls[s.tone]}`}>{String(i + 1).padStart(2, "0")}</div>
              <div>
                <div className={`text-sm font-medium ${toneCls[s.tone]}`}>{s.label}</div>
                <div className="tg-muted text-xs tg-mono mt-0.5">{s.detail}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------- Algorand Ledger ---------------------------------- */

function AlgorandLedger({ agents, treasury, chainTxns }) {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="tg-display font-semibold">Algorand settlement layer</h3>
        <p className="tg-muted text-sm">Every authorized spend settles on-chain. This is the append-only record no policy override can rewrite.</p>
      </div>

      <div className="tg-panel p-4 flex flex-wrap items-center gap-4 justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg tg-panel-raised flex items-center justify-center">
            <Landmark size={18} className="tg-accent-chain" />
          </div>
          <div>
            <div className="text-sm font-medium">Org treasury</div>
            <div className="tg-mono tg-faint text-xs">{genAddr()}</div>
          </div>
        </div>
        <div className="text-right">
          <div className="tg-mono tg-display text-xl font-semibold">{algo(treasury)}</div>
          <div className="tg-faint text-xs">≈ {usd(treasury * ALGO_RATE)} · rate mocked for demo</div>
        </div>
      </div>

      <div className="grid sm:grid-cols-3 gap-3">
        {agents.map((a) => (
          <div key={a.id} className="tg-panel p-3">
            <div className="flex items-center gap-2 mb-1">
              <Bot size={13} className="tg-accent-chain" />
              <span className="text-sm font-medium truncate">{a.name}</span>
            </div>
            <div className="tg-mono tg-faint text-[11px] truncate">{a.wallet}</div>
            <div className="tg-mono text-sm mt-1.5">{algo(a.balance)}</div>
          </div>
        ))}
      </div>

      <div className="tg-panel p-4">
        <div className="flex items-center gap-2 mb-3">
          <Link2 size={14} className="tg-accent-chain" />
          <h4 className="tg-display font-semibold text-sm">On-chain transactions</h4>
        </div>
        <div className="overflow-x-auto tg-scrollbar">
          <table className="w-full text-xs tg-mono min-w-[560px]">
            <thead>
              <tr className="tg-muted text-left border-b tg-hairline">
                <th className="py-2 pr-3 font-normal">Round</th>
                <th className="py-2 pr-3 font-normal">Tx hash</th>
                <th className="py-2 pr-3 font-normal">Agent</th>
                <th className="py-2 pr-3 font-normal">Amount</th>
                <th className="py-2 pr-3 font-normal">Status</th>
              </tr>
            </thead>
            <tbody>
              {chainTxns.length === 0 && (
                <tr><td colSpan={5} className="py-4 tg-faint">No settlements yet — run a request from the x402 Gate tab.</td></tr>
              )}
              {chainTxns.map((t) => (
                <tr key={t.id} className="border-b tg-hairline last:border-0">
                  <td className="py-2 pr-3 tg-faint">{t.round}</td>
                  <td className="py-2 pr-3 tg-accent-chain">{t.txHash}</td>
                  <td className="py-2 pr-3">{t.agentName}</td>
                  <td className="py-2 pr-3">{usd(t.amount)} <span className="tg-faint">({(t.amount / ALGO_RATE).toFixed(1)} ALGO)</span></td>
                  <td className="py-2 pr-3 text-[#3FA66B]">confirmed ✓</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------- Monitoring ---------------------------------- */

function Monitoring({ agents }) {
  const byAgent = agents.map((a) => ({ name: a.name, spend: a.weekSpent }));
  return (
    <div className="space-y-4">
      <div>
        <h3 className="tg-display font-semibold">Monitoring</h3>
        <p className="tg-muted text-sm">Where the money is going, across time, agents, and categories.</p>
      </div>

      <div className="tg-panel p-4">
        <div className="text-sm font-medium mb-3">Org spend, last 7 days</div>
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={weeklyTotals}>
            <CartesianGrid stroke="#232F40" vertical={false} />
            <XAxis dataKey="day" stroke="#5D6B80" fontSize={12} tickLine={false} axisLine={{ stroke: "#232F40" }} />
            <YAxis stroke="#5D6B80" fontSize={12} tickLine={false} axisLine={false} />
            <Tooltip contentStyle={{ background: "#1A2434", border: "1px solid #2B3648", borderRadius: 8, fontSize: 12 }} labelStyle={{ color: "#EDF1F5" }} />
            <Line type="monotone" dataKey="spend" stroke="#4FD1C5" strokeWidth={2} dot={{ r: 3, fill: "#4FD1C5" }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="tg-panel p-4">
          <div className="text-sm font-medium mb-3">Spend by agent, this week</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={byAgent}>
              <CartesianGrid stroke="#232F40" vertical={false} />
              <XAxis dataKey="name" stroke="#5D6B80" fontSize={11} tickLine={false} axisLine={{ stroke: "#232F40" }} />
              <YAxis stroke="#5D6B80" fontSize={12} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ background: "#1A2434", border: "1px solid #2B3648", borderRadius: 8, fontSize: 12 }} labelStyle={{ color: "#EDF1F5" }} />
              <Bar dataKey="spend" fill="#E8A33D" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="tg-panel p-4">
          <div className="text-sm font-medium mb-3">Spend by category</div>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={categoryTotals} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={2}>
                {categoryTotals.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} stroke="#141D2B" />)}
              </Pie>
              <Tooltip contentStyle={{ background: "#1A2434", border: "1px solid #2B3648", borderRadius: 8, fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 11, color: "#8C99AC" }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------- Audit Log ---------------------------------- */

function AuditLog({ txns, onDecide }) {
  const [filter, setFilter] = useState("all");
  const [q, setQ] = useState("");

  const filtered = txns.filter((t) => (filter === "all" || t.status === filter) &&
    (t.agentName.toLowerCase().includes(q.toLowerCase()) || t.service.toLowerCase().includes(q.toLowerCase())));

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="tg-display font-semibold">Audit log</h3>
          <p className="tg-muted text-sm">Immutable record of every authorize / limit / deny decision the engine has made.</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 tg-faint" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search agent or endpoint"
              className="tg-input pl-8 pr-3 py-1.5 text-xs w-52" />
          </div>
        </div>
      </div>

      <div className="flex gap-1.5">
        {["all", "open", "hold", "closed"].map((f) => (
          <button key={f} onClick={() => setFilter(f)}
            className={`tg-mono text-xs px-2.5 py-1 rounded-full border capitalize ${filter === f ? "tg-chip-on" : "tg-chip"}`}>
            {f === "all" ? "all" : f === "open" ? "gate open" : f === "hold" ? "gate hold" : "gate closed"}
          </button>
        ))}
      </div>

      <div className="tg-panel overflow-x-auto tg-scrollbar">
        <table className="w-full text-xs min-w-[720px]">
          <thead>
            <tr className="tg-muted text-left border-b tg-hairline tg-mono">
              <th className="py-2.5 px-3 font-normal">Time</th>
              <th className="py-2.5 px-3 font-normal">Agent</th>
              <th className="py-2.5 px-3 font-normal">Endpoint</th>
              <th className="py-2.5 px-3 font-normal">Amount</th>
              <th className="py-2.5 px-3 font-normal">Status</th>
              <th className="py-2.5 px-3 font-normal">Reason</th>
              <th className="py-2.5 px-3 font-normal">Tx</th>
              <th className="py-2.5 px-3 font-normal"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={8} className="py-6 text-center tg-faint">No matching entries.</td></tr>
            )}
            {filtered.map((t) => (
              <tr key={t.id} className="border-b tg-hairline last:border-0 align-top">
                <td className="py-2.5 px-3 tg-mono tg-faint whitespace-nowrap">{t.time}</td>
                <td className="py-2.5 px-3 whitespace-nowrap">{t.agentName}</td>
                <td className="py-2.5 px-3 tg-mono tg-muted whitespace-nowrap">{t.service}</td>
                <td className="py-2.5 px-3 tg-mono whitespace-nowrap">{usd(t.amount)}</td>
                <td className="py-2.5 px-3"><StampBadge status={t.status} /></td>
                <td className="py-2.5 px-3 tg-muted max-w-[220px]">{t.reason}</td>
                <td className="py-2.5 px-3 tg-mono tg-accent-chain whitespace-nowrap">{t.txHash || "—"}</td>
                <td className="py-2.5 px-3 whitespace-nowrap">
                  {t.status === "hold" && (
                    <div className="flex gap-1.5">
                      <button onClick={() => onDecide(t.id, "open")} className="tg-mono text-[11px] px-2 py-1 rounded border tg-stamp-open">approve</button>
                      <button onClick={() => onDecide(t.id, "closed")} className="tg-mono text-[11px] px-2 py-1 rounded border tg-stamp-closed">deny</button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ---------------------------------- Architecture ---------------------------------- */

function ArchitectureBox({ icon: Icon, title, sub }) {
  return (
    <div className="tg-panel-raised px-4 py-3 flex items-start gap-3 flex-1 min-w-[180px]">
      <Icon size={16} className="tg-accent-chain mt-0.5 shrink-0" />
      <div>
        <div className="text-sm font-medium">{title}</div>
        <div className="tg-faint text-xs mt-0.5">{sub}</div>
      </div>
    </div>
  );
}

function Architecture() {
  const mapping = [
    { req: "Authorize", where: "Policy Rules + x402 Gate", detail: "category allowlist and per-transaction checks run before any call is retried." },
    { req: "Limit", where: "Policy Rules", detail: "daily and per-transaction caps enforced per agent, editable by an operator." },
    { req: "Monitor", where: "Overview + Monitoring", detail: "live gate feed, spend trends, per-agent and per-category breakdowns." },
    { req: "Audit", where: "Audit Log", detail: "append-only trace of every decision with its reason and on-chain reference." },
    { req: "x402 (mandatory)", where: "x402 Gate", detail: "every paid call is modeled as a 402 Payment Required handshake before settlement." },
    { req: "Algorand (mandatory)", where: "Algorand Ledger", detail: "authorized spend settles on-chain with a tx hash and round number." },
  ];
  return (
    <div className="space-y-5">
      <div>
        <h3 className="tg-display font-semibold">How a request moves through the gate</h3>
        <p className="tg-muted text-sm">One flow, six stops — every dollar an agent spends passes through all of them.</p>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <ArchitectureBox icon={Bot} title="AI agent" sub="wants to call a paid API" />
        <ChevronRight size={16} className="tg-faint shrink-0" />
        <ArchitectureBox icon={Zap} title="x402 handshake" sub="service returns 402 Payment Required" />
        <ChevronRight size={16} className="tg-faint shrink-0" />
        <ArchitectureBox icon={ShieldCheck} title="Policy engine" sub="checks category, per-tx cap, daily cap" />
        <ChevronRight size={16} className="tg-faint shrink-0" />
        <ArchitectureBox icon={GitBranch} title="Decision" sub="open, hold for a human, or closed" />
        <ChevronRight size={16} className="tg-faint shrink-0" />
        <ArchitectureBox icon={Landmark} title="Algorand settlement" sub="authorized spend moves on-chain" />
        <ChevronRight size={16} className="tg-faint shrink-0" />
        <ArchitectureBox icon={ListChecks} title="Audit ledger" sub="decision + tx hash recorded permanently" />
      </div>

      <div className="tg-panel p-4">
        <div className="text-sm font-medium mb-3">Problem statement coverage</div>
        <div className="space-y-2">
          {mapping.map((m) => (
            <div key={m.req} className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-4 py-2 border-b tg-hairline last:border-0">
              <div className="tg-mono text-xs tg-accent-signal w-40 shrink-0">{m.req}</div>
              <div className="text-sm w-44 shrink-0">{m.where}</div>
              <div className="tg-muted text-xs">{m.detail}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="tg-panel-raised p-4 text-xs tg-muted leading-relaxed">
        <b className="text-[#EDF1F5]">Demo note —</b> this build simulates the x402 handshake and Algorand settlement client-side (mock tx hashes, mock round numbers, a fixed ALGO/USD rate) so the full authorize → limit → monitor → audit loop can be explored without live credentials. The policy engine's decision logic — category checks, per-transaction caps, and daily caps — runs for real against the state in this session; wiring it to a live x402 facilitator and Algorand testnet node is a drop-in swap of the settlement call.
      </div>
    </div>
  );
}

/* ---------------------------------- App ---------------------------------- */

const TABS = [
  { id: "overview", label: "Overview", icon: Activity },
  { id: "policies", label: "Policies", icon: Shield },
  { id: "gate", label: "x402 Gate", icon: Zap },
  { id: "chain", label: "Algorand Ledger", icon: Landmark },
  { id: "monitoring", label: "Monitoring", icon: TrendingUp },
  { id: "audit", label: "Audit Log", icon: ListChecks },
  { id: "arch", label: "Architecture", icon: GitBranch },
];

export default function App() {
  const [agents, setAgents] = useState(seedAgents);
  const [txns, setTxns] = useState(() => seedTxns(seedAgents()));
  const [treasury, setTreasury] = useState(5230.0);
  const [ticker, setTicker] = useState([]);
  const [tab, setTab] = useState("overview");

  const chainTxns = txns.filter((t) => t.status === "open" && t.txHash);

  const addTicker = useCallback((agentName, text) => {
    setTicker((prev) => [{ id: uid(), time: now(), agentName, text }, ...prev].slice(0, 20));
  }, []);

  const updateAgent = (id, patch) => setAgents((prev) => prev.map((a) => (a.id === id ? { ...a, ...patch } : a)));

  const addAgent = (na) => setAgents((prev) => [...prev, {
    id: uid(), name: na.name, role: na.role || "New agent",
    dailyLimit: na.dailyLimit, perTxLimit: na.perTxLimit, autoApproveUnder: na.autoApproveUnder,
    allowedCategories: na.allowedCategories, spentToday: 0, weekSpent: 0, status: "active",
    wallet: genAddr(), balance: 100,
  }]);

  const handleSettle = (result) => {
    const entry = { id: uid(), time: now(), ...result };
    setTxns((prev) => [entry, ...prev]);
    const label = result.status === "open" ? "settled on-chain — 200 OK" : result.status === "hold" ? "queued for approval" : "denied by policy";
    addTicker(result.agentName, `${result.service} · ${usd(result.amount)} · ${label}`);
    if (result.status === "open") {
      setTreasury((t) => t - result.amount / ALGO_RATE);
      setAgents((prev) => prev.map((a) => a.id === result.agentId ? { ...a, spentToday: +(a.spentToday + result.amount).toFixed(2), weekSpent: +(a.weekSpent + result.amount).toFixed(2) } : a));
    }
  };

  const handleDecide = (id, decision) => {
    setTxns((prev) => prev.map((t) => {
      if (t.id !== id) return t;
      if (decision === "open") {
        const txHash = genTxHash();
        const round = ROUND++;
        addTicker(t.agentName, `${t.service} manually approved · settled ${txHash}`);
        setTreasury((tr) => tr - t.amount / ALGO_RATE);
        setAgents((prev2) => prev2.map((a) => a.id === t.agentId ? { ...a, spentToday: +(a.spentToday + t.amount).toFixed(2), weekSpent: +(a.weekSpent + t.amount).toFixed(2) } : a));
        return { ...t, status: "open", txHash, round, approver: "operator", reason: t.reason + " — manually approved" };
      }
      addTicker(t.agentName, `${t.service} manually denied`);
      return { ...t, status: "closed", approver: "operator", reason: t.reason + " — manually denied" };
    }));
  };

  return (
    <div className="tg-root -m-4 sm:-m-6">
      <style>{GLOBAL_CSS}</style>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6">
        <header className="flex flex-wrap items-center justify-between gap-3 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg tg-panel-raised flex items-center justify-center">
              <Shield size={18} className="tg-accent-chain" />
            </div>
            <div>
              <h1 className="tg-display text-lg font-semibold leading-tight">TOLLGATE</h1>
              <p className="tg-faint text-xs leading-tight">agent spend policy engine · x402 + algorand</p>
            </div>
          </div>
          <div className="tg-mono text-xs tg-muted flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full tg-bg-accent-chain tg-pulse" />
            engine active
          </div>
        </header>

        <nav className="flex gap-1 mb-6 overflow-x-auto tg-scrollbar pb-1">
          {TABS.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`tg-focus flex items-center gap-1.5 px-3 py-2 text-xs rounded-lg border whitespace-nowrap ${tab === t.id ? "tg-tab-active" : "tg-tab"}`}>
              <t.icon size={13} /> {t.label}
            </button>
          ))}
        </nav>

        <main>
          {tab === "overview" && <Overview agents={agents} txns={txns} treasury={treasury} ticker={ticker} setTab={setTab} />}
          {tab === "policies" && <Policies agents={agents} updateAgent={updateAgent} addAgent={addAgent} />}
          {tab === "gate" && <GateSimulator agents={agents} onSettle={handleSettle} />}
          {tab === "chain" && <AlgorandLedger agents={agents} treasury={treasury} chainTxns={chainTxns} />}
          {tab === "monitoring" && <Monitoring agents={agents} />}
          {tab === "audit" && <AuditLog txns={txns} onDecide={handleDecide} />}
          {tab === "arch" && <Architecture />}
        </main>
      </div>
    </div>
  );
}
